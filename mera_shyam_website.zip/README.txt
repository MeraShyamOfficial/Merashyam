# मेरा श्याम

यह एक मुफ्त static website है। इसे GitHub Pages जैसे static hosting पर प्रकाशित किया जा सकता है।

मुख्य फ़ाइल: `index.html`

YouTube / Instagram / Facebook के `#` links को अपने वास्तविक links से बदलें।
